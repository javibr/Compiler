package Errors;

import Compiler.*;

public class CompilerExc extends Exception { 
	
	
	
	
	
}