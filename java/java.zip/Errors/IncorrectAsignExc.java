package Errors;

import Compiler.*;

public class IncorrectAsignExc extends CompilerExc{
	

		public IncorrectAsignExc() {
	        System.out.println("No se puede realizar la asignación de la variable tipos distintos" );
	    }
	 
}