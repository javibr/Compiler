package Compiler;

public class TypBool {
	public static final int tfalse=0;
	public static final int ttrue=1;
	public static final int tunk=2;
}