package Compiler;



public class Args{

String name;


public String getName(){

	return name;
}

public Args(String name){
	this.name=name;
}



}