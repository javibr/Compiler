package Compiler;

public class Typ {
	public static final int tint=0;
	public static final int tbool=1;
	public static final int tstring=2;
}